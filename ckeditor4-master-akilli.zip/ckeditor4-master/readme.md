# akilli ckeditor4

CKEditor 4 plugins and builds.
