'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('gallery', 'en', {
        title: 'Gallery'
    });
})(CKEDITOR);
