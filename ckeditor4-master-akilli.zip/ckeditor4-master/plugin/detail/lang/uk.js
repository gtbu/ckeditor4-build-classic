'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('detail', 'uk', {
        title: 'Деталі'
    });
})(CKEDITOR);
