# Details Widget

This widget provides support for *details* and *summary* elements. 

No configuration necessary.

## Demo

- [Classic Editor](https://akilli.github.io/ckeditor4-build-classic/demo)
- [Inline Editor](https://akilli.github.io/ckeditor4-build-inline/demo)
