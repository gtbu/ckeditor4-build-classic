'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('grid', 'en', {
        title: 'Grid'
    });
})(CKEDITOR);
