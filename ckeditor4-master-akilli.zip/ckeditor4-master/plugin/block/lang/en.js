'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('block', 'en', {
        content: 'Content',
        id: 'ID',
        info: 'Info',
        title: 'Block',
        validateRequired: 'This field is required'
    });
})(CKEDITOR);
