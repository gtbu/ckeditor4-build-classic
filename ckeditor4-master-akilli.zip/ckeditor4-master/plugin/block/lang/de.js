'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('block', 'de', {
        content: 'Inhalt',
        id: 'ID',
        info: 'Info',
        title: 'Block',
        validateRequired: 'Dieses Feld ist erforderlich'
    });
})(CKEDITOR);
